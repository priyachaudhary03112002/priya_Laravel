<h1> Hy how are you priya </h1>
<?php echo e("i am fine"); ?> <br>
<?php echo e("Ok, Good"); ?> <br>
<?php
echo 10+10
?> <br>
<?php $name="Zalak"?>
<?php if($name=="Zalak"): ?>
<h1>Hi my name is <?php echo e($name); ?></h1>
<?php elseif($name=="Mahesh"): ?>
<h1>Hi my name is <?php echo e($name); ?></h1>
<?php else: ?>
<h1>Unknown</h1>	
<?php endif; ?>

<?php for($i=1;$i<=10;$i++): ?>
<h4><?php echo e($i); ?></h4>	
<?php endfor; ?>

<?php $data=['sam','raj','mahesh'];?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h4><?php echo e($d); ?></h4>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php /**PATH C:\xampp\htdocs\priya\myproject\resources\views/mypage.blade.php ENDPATH**/ ?>