@include('frontend.layout.header')
@yield('main_section')
@include('frontend.layout.footer')